"""
Base class for simple MCP tools.

Simple tools follow a straightforward pattern:
1. Receive request
2. Prepare prompt (with files, context, etc.)
3. Call AI model
4. Format and return response

They use the shared SchemaBuilder for consistent schema generation
and inherit all the conversation, file processing, and model handling
capabilities from BaseTool.
"""

from abc import abstractmethod
from typing import Any, Optional

from tools.shared.base_models import ToolRequest
from tools.shared.base_tool import BaseTool
from tools.shared.schema_builders import SchemaBuilder
from tools.simple.mixins import WebSearchMixin, ToolCallMixin, StreamingMixin, ContinuationMixin

from mcp.types import TextContent

from utils.client_info import get_current_session_fingerprint, get_cached_client_info, format_client_info
from utils.progress import send_progress
from utils.progress_utils.messages import ProgressMessages

# Import the registry for model selection
from src.providers.registry_core import get_registry_instance


class SimpleTool(WebSearchMixin, ToolCallMixin, StreamingMixin, ContinuationMixin, BaseTool):
    """
    Base class for simple (non-workflow) tools.

    Simple tools are request/response tools that don't require multi-step workflows.
    They benefit from:
    - Automatic schema generation using SchemaBuilder
    - Inherited conversation handling and file processing
    - Standardized model integration
    - Consistent error handling and response formatting

    To create a simple tool:
    1. Inherit from SimpleTool
    2. Implement get_tool_fields() to define tool-specific fields
    3. Implement prepare_prompt() for prompt preparation
    4. Optionally override format_response() for custom formatting
    5. Optionally override get_required_fields() for custom requirements

    Example:
        class ChatTool(SimpleTool):
            def get_name(self) -> str:
                return "chat"

            def get_tool_fields(self) -> Dict[str, Dict[str, Any]]:
                return {
                    "prompt": {
                        "type": "string",
                        "description": "Your question or idea...",
                    },
                    "files": SimpleTool.FILES_FIELD,
                }

            def get_required_fields(self) -> List[str]:
                return ["prompt"]
    """

    # Common field definitions that simple tools can reuse
    # Now delegated to SimpleToolSchemaBuilder for better separation of concerns
    @property
    def FILES_FIELD(self) -> dict[str, Any]:
        """Get FILES field schema from Definition Module"""
        from tools.simple.definition.schema import SimpleToolSchemaBuilder
        return SimpleToolSchemaBuilder.get_files_field()

    @property
    def IMAGES_FIELD(self) -> dict[str, Any]:
        """Get IMAGES field schema from Definition Module"""
        from tools.simple.definition.schema import SimpleToolSchemaBuilder
        return SimpleToolSchemaBuilder.get_images_field()

    @abstractmethod
    def get_tool_fields(self) -> dict[str, dict[str, Any]]:
        """
        Return tool-specific field definitions.

        This method should return a dictionary mapping field names to their
        JSON schema definitions. Common fields (model, temperature, etc.)
        are added automatically by the base class.

        Returns:
            Dict mapping field names to JSON schema objects

        Example:
            return {
                "prompt": {
                    "type": "string",
                    "description": "The user's question or request",
                },
                "files": SimpleTool.FILES_FIELD,  # Reuse common field
                "max_tokens": {
                    "type": "integer",
                    "minimum": 1,
                    "description": "Maximum tokens for response",
                }
            }
        """
        pass

    def get_required_fields(self) -> list[str]:
        """
        Return list of required field names.

        Override this to specify which fields are required for your tool.
        The model field is automatically added if in auto mode.

        Returns:
            List of required field names
        """
        return []

    def get_annotations(self) -> Optional[dict[str, Any]]:
        """
        Return tool annotations. Simple tools are read-only by default.

        All simple tools perform operations without modifying the environment.
        They may call external AI models for analysis or conversation, but they
        don't write files or make system changes.

        Override this method if your simple tool needs different annotations.

        Returns:
            Dictionary with readOnlyHint set to True
        """
        return {"readOnlyHint": True}

    def _clean_model_artifacts(self, response: str) -> str:
        """
        Remove model-specific artifacts from response.

        CRITICAL FIX (Bug #6): Clean up artifacts that some models add to responses:
        - GLM-4.5v: <|begin_of_box|>, <|end_of_box|> tags
        - GLM-4.5-flash: "AGENT'S TURN:" suffix
        - Progress markers: === PROGRESS === sections

        This cleaning was previously only in the WebSocket shim (run_ws_shim.py),
        but needs to be in core response handling to work for all clients.

        Args:
            response: Raw response from model

        Returns:
            Cleaned response string
        """
        import re

        # Remove GLM-4.5v box markers
        response = re.sub(r'<\|begin_of_box\|>', '', response)
        response = re.sub(r'<\|end_of_box\|>', '', response)

        # Remove progress sections (=== PROGRESS === ... === END PROGRESS ===)
        response = re.sub(r'=== PROGRESS ===.*?=== END PROGRESS ===\n*', '', response, flags=re.DOTALL)

        # Remove "AGENT'S TURN:" suffix (GLM-4.5-flash artifact)
        response = re.sub(r"\n*---\n*\n*AGENT'S TURN:.*", '', response, flags=re.DOTALL)

        return response.strip()

    def format_response(self, response: str, request, model_info: Optional[dict] = None) -> str:
        """
        Format the AI response before returning to the client.

        This is a hook method that subclasses can override to customize
        response formatting. The default implementation cleans model artifacts
        and returns the response.

        Args:
            response: The raw response from the AI model
            request: The validated request object
            model_info: Optional model information dictionary

        Returns:
            Formatted response string
        """
        # CRITICAL FIX (Bug #6): Clean model artifacts before returning
        return self._clean_model_artifacts(response)

    def get_input_schema(self) -> dict[str, Any]:
        """
        Generate the complete input schema using SchemaBuilder.

        This method automatically combines:
        - Tool-specific fields from get_tool_fields()
        - Common fields (temperature, thinking_mode, etc.)
        - Model field with proper auto-mode handling
        - Required fields from get_required_fields()

        Tools can override this method for custom schema generation while
        still benefiting from SimpleTool's convenience methods.

        Returns:
            Complete JSON schema for the tool

        Note:
            Schema generation is now delegated to SimpleToolSchemaBuilder
            in the Definition Module for better separation of concerns.
        """
        from tools.simple.definition.schema import SimpleToolSchemaBuilder
        return SimpleToolSchemaBuilder.build_input_schema(self)

    def get_request_model(self):
        """
        Return the request model class.

        Simple tools use the base ToolRequest by default.
        Override this if your tool needs a custom request model.
        """
        return ToolRequest

    # Hook methods for safe attribute access without hasattr/getattr
    # Now delegated to RequestAccessor in Intake Module for better separation of concerns

    def get_request_model_name(self, request) -> Optional[str]:
        """Get model name from request. Override for custom model name handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_model_name(request)

    def get_request_images(self, request) -> list:
        """Get images from request. Override for custom image handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_images(request)

    def get_request_continuation_id(self, request) -> Optional[str]:
        """Get continuation_id from request. Override for custom continuation handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_continuation_id(request)

    def get_request_prompt(self, request) -> str:
        """Get prompt from request. Override for custom prompt handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_prompt(request)

    def get_request_temperature(self, request) -> Optional[float]:
        """Get temperature from request. Override for custom temperature handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_temperature(request)

    def get_validated_temperature(self, request, model_context: Any) -> tuple[float, list[str]]:
        """
        Get temperature from request and validate it against model constraints.

        This is a convenience method that combines temperature extraction and validation
        for simple tools. It ensures temperature is within valid range for the model.

        Args:
            request: The request object containing temperature
            model_context: Model context object containing model info

        Returns:
            Tuple of (validated_temperature, warning_messages)
        """
        temperature = self.get_request_temperature(request)
        if temperature is None:
            temperature = self.get_default_temperature()
        return self.validate_and_correct_temperature(temperature, model_context)

    def get_request_thinking_mode(self, request) -> Optional[str]:
        """Get thinking_mode from request. Override for custom thinking mode handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_thinking_mode(request)

    def get_request_files(self, request) -> list:
        """Get files from request. Override for custom file handling."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_files(request)

    def get_request_use_websearch(self, request) -> bool:
        """Get use_websearch from request, falling back to env default.
        EX_WEBSEARCH_DEFAULT_ON controls default when request doesn't specify.
        """
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_use_websearch(request)

    def get_request_as_dict(self, request) -> dict:
        """Convert request to dictionary. Override for custom serialization."""
        from tools.simple.intake.accessor import RequestAccessor
        return RequestAccessor.get_as_dict(request)

    def set_request_files(self, request, files: list) -> None:
        """Set files on request. Override for custom file setting."""
        from tools.simple.intake.accessor import RequestAccessor
        RequestAccessor.set_files(request, files)

    def get_actually_processed_files(self) -> list:
        """Get actually processed files. Override for custom file tracking."""
        try:
            return self._actually_processed_files
        except AttributeError:
            return []

    async def execute(
        self,
        arguments: dict[str, Any],
        on_chunk: Optional[Any] = None  # NEW: Streaming callback
    ) -> list:
        """
        Execute the simple tool using the comprehensive flow from old base.py.

        This method replicates the proven execution pattern while using SimpleTool hooks.
        """
        import json
        import logging


        from tools.models import ToolOutput

        logger = logging.getLogger(f"tools.{self.get_name()}")
        logger.info(f"TOOL_EXEC_DEBUG: execute() method ENTERED for tool '{self.get_name()}'")

        try:
            # Store arguments for access by helper methods
            self._current_arguments = arguments

            # NEW (2025-10-24): Store streaming callback for provider access
            self._on_chunk_callback = on_chunk

            # FIX: Handle both dict and ToolRequest object types
            if hasattr(arguments, 'keys'):
                logger.info(f"{self.get_name()} tool called with arguments: {list(arguments.keys())}")
            else:
                logger.info(f"{self.get_name()} tool called with request object: {type(arguments).__name__}")
            logger.info(f"TOOL_EXEC_DEBUG: Arguments stored, about to send progress")
            try:
                from utils.progress import send_progress
                send_progress(f"{self.get_name()}: Starting execution")
            except Exception:
                pass

            # Validate request using the tool's Pydantic model
            # FIX: Handle both dict and already-validated request objects
            request_model = self.get_request_model()
            if isinstance(arguments, request_model):
                # Arguments is already a validated request object
                request = arguments
            else:
                # Arguments is a dict, validate it
                request = request_model(**arguments)
            logger.debug(f"Request validation successful for {self.get_name()}")
            try:
                from utils.progress import send_progress
                send_progress(f"{self.get_name()}: Request validated")
            except Exception as progress_err:
                # Non-critical: Progress notification failure shouldn't break tool execution
                logger.debug(f"Failed to send progress notification: {progress_err}")

            # Validate file paths for security
            # This prevents path traversal attacks and ensures proper access control
            path_error = self._validate_file_paths(request)
            if path_error:
                error_output = ToolOutput(
                    status="error",
                    content=path_error,
                    content_type="text",
                )
                return [TextContent(type="text", text=error_output.model_dump_json())]

            # Handle model resolution like old base.py
            model_name = self.get_request_model_name(request)
            if not model_name:
                from config import DEFAULT_MODEL

                model_name = DEFAULT_MODEL

            # Store the current model name for later use
            self._current_model_name = model_name

            # Handle model context from arguments (for in-process testing)
            # FIX: Check if arguments is dict before checking for key
            if isinstance(arguments, dict) and "_model_context" in arguments:
                self._model_context = arguments["_model_context"]
                logger.debug(f"{self.get_name()}: Using model context from arguments")
            else:
                # Create model context if not provided
                from utils.model.context import ModelContext
                from src.providers.registry_core import get_registry_instance
                # Avoid constructing ModelContext('auto') which triggers provider lookup error.
                if (model_name or "").strip().lower() == "auto":
                    try:
                        registry_instance = get_registry_instance()
                        seed = registry_instance.get_preferred_fallback_model(self.get_model_category())
                    except Exception:
                        seed = None
                    seed = seed or "glm-4.5-flash"
                    self._model_context = ModelContext(seed)
                    logger.debug(f"{self.get_name()}: Auto-mode seed context created for {seed}")
                else:
                    logger.info(f"TOOL_EXEC_DEBUG: About to create ModelContext for model '{model_name}'")
                    self._model_context = ModelContext(model_name)
                    logger.info(f"TOOL_EXEC_DEBUG: ModelContext created successfully for {model_name}")
                    logger.debug(f"{self.get_name()}: Created model context for {model_name}")

            try:
                from utils.progress import send_progress
                send_progress(f"{self.get_name()}: Model/context ready: {model_name}")
            except Exception:
                pass

            # Get images if present
            images = self.get_request_images(request)
            continuation_id = self.get_request_continuation_id(request)

            # Handle conversation history and prompt preparation
            if continuation_id:
                # Check if conversation history is already embedded
                field_value = self.get_request_prompt(request)
                if "=== CONVERSATION HISTORY ===" in field_value:
                    # Use pre-embedded history
                    prompt = field_value
                    logger.debug(f"{self.get_name()}: Using pre-embedded conversation history")
                else:
                    # No embedded history - reconstruct it (for in-process calls)
                    logger.debug(f"{self.get_name()}: No embedded history found, reconstructing conversation")

                    # Get thread context
                    # BUG FIX #14 (2025-10-20): Removed build_conversation_history import (deleted function)
                    # CRITICAL FIX (2025-10-24): Use global_storage to prevent 4x Supabase duplication
                    from utils.conversation.global_storage import add_turn, get_thread

                    thread_context = get_thread(continuation_id)

                    if thread_context:
                        # CRITICAL FIX (2025-10-19): Removed duplicate message saving
                        # ContinuationMixin already handles saving user turns to Supabase
                        # This was causing duplicate messages in the database
                        # The thread_context is already updated by ContinuationMixin

                        # Just log that we're using the thread context
                        logger.debug(
                            f"{self.get_name()}: Using thread context with {len(thread_context.turns)} turns"
                        )

                        # BUG FIX #14 (2025-10-20): No longer build text-based conversation history
                        # Modern approach: Request handler provides _messages parameter to SDK providers
                        # Tools receive conversation context via message arrays, not text strings

                        # Get the base prompt from the tool
                        base_prompt = await self.prepare_prompt(request)

                        # Use base prompt directly - conversation history is handled via _messages
                        prompt = base_prompt
                    else:
                        # Thread not found, prepare normally
                        logger.warning(f"Thread {continuation_id} not found, preparing prompt normally")
                        prompt = await self.prepare_prompt(request)
            else:
                # New conversation, prepare prompt normally
                prompt = await self.prepare_prompt(request)

                # Add follow-up instructions for new conversations
                from server import get_follow_up_instructions

                follow_up_instructions = get_follow_up_instructions(0)
                prompt = f"{prompt}\n\n{follow_up_instructions}"
                logger.debug(
                    f"Added follow-up instructions for new {self.get_name()} conversation"
                )  # Validate images if any were provided
            if images:
                image_validation_error = self._validate_image_limits(
                    images, model_context=self._model_context, continuation_id=continuation_id
                )
                if image_validation_error:
                    return [TextContent(type="text", text=json.dumps(image_validation_error, ensure_ascii=False))]

            # Get and validate temperature against model constraints
            temperature, temp_warnings = self.get_validated_temperature(request, self._model_context)

            # Log any temperature corrections
            for warning in temp_warnings:
                # Get thinking mode with defaults
                logger.warning(warning)
            thinking_mode = self.get_request_thinking_mode(request)
            if thinking_mode is None:
                thinking_mode = self.get_default_thinking_mode()

            # Get the provider from model context (clean OOP - no re-fetching)
            logger.info(f"TOOL_EXEC_DEBUG: About to access provider property for model '{self._current_model_name}'")
            logger.info(f"TOOL_EXEC_DEBUG: Model context object: {self._model_context}")
            provider = self._model_context.provider
            logger.info(f"TOOL_EXEC_DEBUG: Provider obtained: {provider}")

            # Get system prompt for this tool
            base_system_prompt = self.get_system_prompt()
            language_instruction = self.get_language_instruction()

            # Add strong web search instruction if enabled
            use_websearch = self.get_request_use_websearch(request)
            web_search_instruction = ""
            if use_websearch:
                web_search_instruction = (
                    "\n\n=== CRITICAL WEB SEARCH INSTRUCTIONS ===\n"
                    "When web search results are provided in tool responses:\n"
                    "1. You MUST use ONLY the information from the search results\n"
                    "2. Do NOT use your training data for factual claims, pricing, specifications, or current information\n"
                    "3. If search results conflict with your training data, TRUST THE SEARCH RESULTS\n"
                    "4. Cite sources from search results when available\n"
                    "5. If search results are insufficient, explicitly state what's missing\n"
                    "6. For pricing queries: Report EXACT numbers from search results, do not round or estimate\n"
                    "=== END CRITICAL INSTRUCTIONS ===\n\n"
                )

            system_prompt = language_instruction + web_search_instruction + base_system_prompt

            # Estimate tokens for logging
            from utils.model.token_utils import estimate_tokens

            estimated_tokens = estimate_tokens(prompt)
            logger.debug(f"Prompt length: {len(prompt)} characters (~{estimated_tokens:,} tokens)")
            try:
                from utils.progress import send_progress
                send_progress(f"{self.get_name()}: Generating response (~{estimated_tokens:,} tokens)")
            except Exception:
                pass

            # Generate AI response with fallback (free-first → paid) when applicable
            import os as _os
            from src.providers.registry import get_registry
            selected_model = self._current_model_name
            tool_call_metadata = []  # collected sanitized tool-call events for UI dropdown

            # Create async bridge helper
            import asyncio
            import inspect

            async def _call_with_model_async(_model_name: str):
                """Async version of the model call logic."""
                nonlocal selected_model, provider
                selected_model = _model_name
                registry_instance = get_registry()
                prov = registry_instance.get_provider_for_model(_model_name)
                if not prov:
                    raise RuntimeError(f"No provider available for model '{_model_name}'")
                provider = prov  # update for downstream logging/usage
                # Provider-native web browsing via capability layer (centralized)
                provider_kwargs = {}
                web_event = None
                try:
                    from src.providers.orchestration.websearch_adapter import build_websearch_provider_kwargs
                    use_web = self.get_request_use_websearch(request)
                    provider_kwargs, web_event = build_websearch_provider_kwargs(
                        provider_type=prov.get_provider_type(),
                        use_websearch=use_web,
                        model_name=_model_name,  # CRITICAL: Pass model name to check websearch support
                        include_event=True,
                    )
                    if web_event is not None:
                        try:
                            tool_call_metadata.append({
                                "provider": web_event.provider,
                                "tool_name": web_event.tool_name,
                                "args": web_event.args,
                                "start_ts": web_event.start_ts,
                            })
                        except Exception:
                            pass
                except Exception:
                    web_event = None

                # PHASE 4 (2025-10-23): Add continuation_id to provider_kwargs for session tracking
                # CRITICAL: Must be AFTER build_websearch_provider_kwargs to avoid being overwritten
                continuation_id = self.get_request_continuation_id(request)
                if continuation_id:
                    provider_kwargs["continuation_id"] = continuation_id
                # Streaming enablement centralized
                try:
                    from src.providers.orchestration.streaming_flags import is_streaming_enabled
                    if is_streaming_enabled(getattr(prov.get_provider_type(), "value", ""), getattr(self, "get_name", lambda: "")()):
                        provider_kwargs["stream"] = True
                except Exception:
                    pass
                # NEW (2025-10-24): Pass streaming callback to provider
                if hasattr(self, '_on_chunk_callback') and self._on_chunk_callback and prov.supports_streaming(_model_name):
                    provider_kwargs["on_chunk"] = self._on_chunk_callback

                # CRITICAL FIX (2025-10-26): Add logging to verify actual API calls
                # This helps identify when semantic cache or mock mode is being used
                import time as _time
                logger.info(f"[{self.get_name()}] CALLING PROVIDER: {prov.__class__.__name__} with prompt length {len(prompt)}")
                call_start = _time.time()

                # Build kwargs dict, excluding images if not supported
                generate_kwargs = {
                    "prompt": prompt,
                    "model_name": _model_name,
                    "system_prompt": system_prompt,
                    "temperature": temperature,
                    **provider_kwargs,
                }

                # Only add thinking_mode if supported
                thinking_mode_value = thinking_mode if prov.supports_thinking_mode(_model_name) else None
                if thinking_mode_value:
                    generate_kwargs["thinking_mode"] = thinking_mode_value

                # Only add images if provider supports it
                if images and prov.supports_images(_model_name):
                    generate_kwargs["images"] = images

                # Only add on_chunk if provider supports streaming
                if hasattr(self, '_on_chunk_callback') and self._on_chunk_callback and prov.supports_streaming(_model_name):
                    generate_kwargs["on_chunk"] = self._on_chunk_callback

                # Handle async provider calls - we're in an async function, so use await
                result = await prov.generate_content(**generate_kwargs)

                # Log response time to verify real API calls (should be >100ms for real AI)
                call_duration_ms = (_time.time() - call_start) * 1000
                response_length = len(getattr(result, 'content', ''))
                logger.info(f"[{self.get_name()}] PROVIDER RESPONSE: {response_length} chars in {call_duration_ms:.1f}ms")

                return result

            # Sync wrapper for _call_with_model_async to bridge with call_with_fallback
            def _call_with_model(_model_name: str):
                import asyncio
                import threading
                import concurrent.futures

                # Try to get the running loop
                try:
                    loop = asyncio.get_running_loop()
                    # We're in an async context - use a new thread with its own event loop
                    logger.warning(f"[DEBUG] Using thread-based execution for model '{_model_name}' (async context detected)")
                    result_container = []
                    exception_container = []

                    def run_in_thread():
                        new_loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(new_loop)
                        try:
                            result = new_loop.run_until_complete(_call_with_model_async(_model_name))
                            result_container.append(result)
                        except Exception as e:
                            import traceback
                            exception_container.append(e)
                        finally:
                            new_loop.close()

                    thread = threading.Thread(target=run_in_thread, daemon=True)
                    thread.start()
                    thread.join(timeout=120)  # 2 minute timeout

                    if exception_container:
                        raise exception_container[0]
                    if not result_container:
                        raise TimeoutError(f"Model call timed out for model '{_model_name}'")
                    return result_container[0]

                except RuntimeError as e:
                    # No running loop, safe to use asyncio.run()
                    logger.warning(f"[DEBUG] Using asyncio.run() for model '{_model_name}' (sync context detected)")
                    return asyncio.run(_call_with_model_async(_model_name))

            # Honor explicit model first; only use hybrid router when model=='auto' or on failure if enabled
            _fb_on_failure = _os.getenv("FALLBACK_ON_FAILURE", "true").strip().lower() == "true"
            _is_auto = (self._current_model_name or "").strip().lower() == "auto"

            if not _is_auto:
                # Try direct call to the explicitly-resolved model
                try:
                    logger.info(f"Sending request to {provider.get_provider_type().value} API for {self.get_name()}")
                    logger.info(
                        f"Using model: {self._model_context.model_name} via {provider.get_provider_type().value} provider"
                    )
                    # Provider-native web browsing via capability layer (centralized)
                    provider_kwargs = {}
                    try:
                        from src.providers.orchestration.websearch_adapter import build_websearch_provider_kwargs
                        use_web = self.get_request_use_websearch(request)
                        provider_kwargs, _ = build_websearch_provider_kwargs(
                            provider_type=provider.get_provider_type(),
                            use_websearch=use_web,
                            model_name=self._model_context.model_name,  # CRITICAL: Pass model name to check websearch support
                            include_event=False,
                        )
                    except Exception:
                        pass
                    # Streaming enablement centralized
                    try:
                        from src.providers.orchestration.streaming_flags import is_streaming_enabled
                        if is_streaming_enabled(getattr(provider.get_provider_type(), "value", ""), getattr(self, "get_name", lambda: "")()):
                            provider_kwargs["stream"] = True
                    except Exception:
                        pass

                    # PHASE 4 (2025-10-23): Add continuation_id to provider_kwargs for session tracking
                    # CRITICAL: This is the DIRECT CALL PATH (non-fallback) - must add continuation_id here too
                    continuation_id = self.get_request_continuation_id(request)
                    if continuation_id:
                        provider_kwargs["continuation_id"] = continuation_id

                    # NEW (2025-10-24): Pass streaming callback to provider (direct call path)
                    if hasattr(self, '_on_chunk_callback') and self._on_chunk_callback and provider.supports_streaming(self._current_model_name):
                        provider_kwargs["on_chunk"] = self._on_chunk_callback

                    # Try semantic cache first
                    from utils.infrastructure.semantic_cache import get_semantic_cache
                    import hashlib
                    cache = get_semantic_cache()

                    # Hash system prompt to avoid false cache hits from truncation
                    system_prompt_hash = None
                    if system_prompt:
                        system_prompt_hash = hashlib.sha256(system_prompt.encode()).hexdigest()[:16]

                    cached_response = cache.get(
                        prompt=prompt,
                        model=self._current_model_name,
                        temperature=temperature,
                        thinking_mode=thinking_mode if provider.supports_thinking_mode(self._current_model_name) else None,
                        use_websearch=self.get_request_use_websearch(request),
                        system_prompt_hash=system_prompt_hash,  # Use hash instead of truncated text
                    )

                    if cached_response is not None:
                        logger.info(f"Semantic cache HIT for {self.get_name()} (model={self._current_model_name})")
                        model_response = cached_response
                    else:
                        logger.debug(f"Semantic cache MISS for {self.get_name()} (model={self._current_model_name})")

                        # Build kwargs dict, excluding images if not supported
                        generate_kwargs = {
                            "prompt": prompt,
                            "model_name": self._current_model_name,
                            "system_prompt": system_prompt,
                            "temperature": temperature,
                            **provider_kwargs,
                        }

                        # Only add thinking_mode if supported
                        thinking_mode_value = thinking_mode if provider.supports_thinking_mode(self._current_model_name) else None
                        if thinking_mode_value:
                            generate_kwargs["thinking_mode"] = thinking_mode_value

                        # Only add images if provider supports it
                        if images and provider.supports_images(self._current_model_name):
                            generate_kwargs["images"] = images

                        # Handle async provider calls - already in async context
                        model_response = await provider.generate_content(**generate_kwargs)

                        # Cache the response
                        if model_response is not None:
                            cache.set(
                                prompt=prompt,
                                model=self._current_model_name,
                                response=model_response,
                                temperature=temperature,
                                thinking_mode=thinking_mode if provider.supports_thinking_mode(self._current_model_name) else None,
                                use_websearch=self.get_request_use_websearch(request),
                                system_prompt_hash=system_prompt_hash,  # Use hash instead of truncated text
                            )
                except Exception as _explicit_err:
                    if _fb_on_failure:
                        logger.warning(f"Explicit model call failed; entering hybrid router fallback: {str(_explicit_err)}")
                        model_response = await self._route_and_execute(request, _call_with_model, is_retry=True)
                    else:
                        raise
            else:
                # Auto mode: use hybrid router for intelligent routing
                logger.info("Using hybrid router for auto model selection")
                model_response = await self._route_and_execute(request, _call_with_model, is_retry=False)

            logger.info(f"Received response from {provider.get_provider_type().value} API for {self.get_name()}")
            send_progress(ProgressMessages.processing_response())

            # Defensive: handle missing provider response (None)
            if model_response is None:
                logger.error(f"Model call returned None in {self.get_name()} - treating as error")
                send_progress(ProgressMessages.error("Model returned no response"))
                tool_output = ToolOutput(
                    status="error",
                    content="Model returned no response (None). Please retry or switch model; check provider logs for details.",
                    content_type="text",
                )
                return [TextContent(type="text", text=tool_output.model_dump_json())]

            # HYBRID PATTERN: DISABLED (2025-10-15)
            # GLM-4.6 with tool_stream=True now uses web search natively and correctly
            # The fallback was triggering unnecessarily because GLM embeds search results
            # without specific markers like "[Web Search Results]"
            #
            # DECISION: Trust GLM's native web search implementation
            # If GLM doesn't search when it should, that's a prompt/model issue, not a code issue
            #
            # Original logic kept below for reference but commented out:
            """
            use_websearch = self.get_request_use_websearch(request)
            if use_websearch and self.get_name() == "chat":
                # Check if response contains web search results
                response_content = getattr(model_response, "content", "")
                has_search_results = (
                    "[Web Search Results]" in response_content or
                    "search_result" in response_content.lower() or
                    "web search" in response_content.lower()
                )
                if not has_search_results:
                    logger.info("Web search requested but not found in response - executing fallback search")
                    send_progress(ProgressMessages.executing_tool("web_search"))

                    try:
                        # CRITICAL FIX (2025-10-19): Use internal function instead of nested tool call
                        # This prevents client cancellation of nested tool calls
                        # Import internal web search function
                        from src.providers.tool_executor import perform_glm_web_search
                        import asyncio

                        # Extract search query from user prompt
                        user_prompt = self.get_request_prompt(request)
                        search_query = user_prompt[:200]  # Use first 200 chars as query

                        # Execute web search internally (no nested tool call)
                        logger.debug(f"Executing internal web search for query: {search_query[:50]}...")
                        search_data = await asyncio.to_thread(
                            perform_glm_web_search,
                            search_query,
                            count=10,
                            search_recency_filter="oneWeek"
                        )

                        # Append search results to response
                        if search_data:
                            import json as _json
                            search_results_text = f"\n\n=== WEB SEARCH RESULTS ===\n{_json.dumps(search_data, indent=2, ensure_ascii=False)}\n"

                            # Update model response content
                            if hasattr(model_response, 'content'):
                                model_response.content = response_content + search_results_text
                                logger.info(f"Web search completed successfully, appended {len(search_data.get('results', []))} results")
                                logger.info("Successfully appended fallback web search results to response")
                                send_progress(ProgressMessages.tool_complete("web_search"))

                    except Exception as e:
                        logger.warning(f"Fallback web search failed: {e}")
                        # Continue without search results - don't fail the entire request
            """

            # Check if model requested tool calls (web_search, etc.)
            # Tool_calls are stored in the raw response within metadata
            tool_calls_list = None
            try:
                from src.providers.tool_executor import extract_tool_calls, execute_tool_call

                # Get metadata from model response
                metadata = getattr(model_response, "metadata", {})
                if isinstance(metadata, dict):
                    # Try to extract tool_calls from raw response
                    raw_dict = metadata.get("raw", {})
                    if isinstance(raw_dict, dict):
                        tool_calls_list = extract_tool_calls(raw_dict)

                        if tool_calls_list:
                            logger.info(f"Detected {len(tool_calls_list)} tool call(s) from model response")
                            send_progress(ProgressMessages.tool_call_detected("tool", len(tool_calls_list)))
            except Exception as e:
                logger.debug(f"Failed to check for tool_calls: {e}")
                tool_calls_list = None

            if tool_calls_list:
                # Model wants to use tools - execute them and continue conversation
                # Loop until finish_reason != "tool_calls" (Kimi pattern)
                try:
                    max_iterations = 5  # Prevent infinite loops
                    iteration = 0

                    # Build messages list for multi-turn conversation
                    conv_messages = []
                    if system_prompt:
                        conv_messages.append({"role": "system", "content": system_prompt})
                    conv_messages.append({"role": "user", "content": prompt})

                    # Tool call loop - continue until model is satisfied
                    while tool_calls_list and iteration < max_iterations:
                        iteration += 1
                        logger.info(f"Tool call iteration {iteration}: {len(tool_calls_list)} tool(s) requested")

                        # Add assistant message with tool_calls
                        conv_messages.append({
                            "role": "assistant",
                            "content": getattr(model_response, "content", "") or "",
                            "tool_calls": tool_calls_list
                        })

                        # Execute each tool call and add results
                        for tc in tool_calls_list:
                            # Check if this is a builtin_function (server-side execution)
                            if tc.get("type") == "builtin_function":
                                # Server-side tool (e.g., Kimi $web_search)
                                # According to Kimi documentation:
                                # - The search was ALREADY executed by Kimi's API server
                                # - Search results are embedded in the assistant message content
                                # - We just need to acknowledge with empty content
                                # - The model will use the search results from its own response
                                func_name = tc.get("function", {}).get("name", "unknown")
                                send_progress(ProgressMessages.tool_complete(func_name))

                                logger.info(f"Acknowledging server-side tool: {func_name}")

                                # Acknowledge with empty content as per Kimi docs
                                # The search results are already in the assistant message content
                                tool_msg = {
                                    "role": "tool",
                                    "tool_call_id": str(tc.get("id", "tc-0")),
                                    "name": func_name,
                                    "content": ""  # Empty as per Kimi documentation
                                }
                            else:
                                # Client-side tool execution
                                func_name = tc.get("function", {}).get("name", "unknown")
                                send_progress(ProgressMessages.executing_tool(func_name))
                                tool_msg = execute_tool_call(tc)
                                send_progress(ProgressMessages.tool_complete(func_name))

                            conv_messages.append(tool_msg)

                        # Continue conversation with tool results
                        logger.info(f"Sending tool results back to model (iteration {iteration})...")

                        # Don't send tools parameter in follow-up call
                        follow_up_kwargs = {k: v for k, v in provider_kwargs.items() if k not in ("tools", "tool_choice")}

                        if hasattr(provider, "chat_completions_create"):
                            result_dict = provider.chat_completions_create(
                                model=self._current_model_name,
                                messages=conv_messages,
                                temperature=temperature,
                                **follow_up_kwargs
                            )

                            # Convert dict response to ModelResponse
                            from src.providers.base import ModelResponse, ProviderType
                            model_response = ModelResponse(
                                content=result_dict.get("content", ""),
                                usage=result_dict.get("usage", {}),
                                model_name=result_dict.get("model", self._current_model_name),
                                friendly_name=result_dict.get("provider", ""),
                                provider=getattr(provider, "get_provider_type", lambda: ProviderType.KIMI)(),
                                metadata=result_dict.get("metadata", {})
                            )

                            # Check finish_reason to see if we should continue
                            finish_reason = result_dict.get("choices", [{}])[0].get("finish_reason")
                            logger.info(f"Iteration {iteration} finish_reason: {finish_reason}")

                            # Extract new tool_calls if any
                            from src.providers.tool_executor import extract_tool_calls
                            tool_calls_list = extract_tool_calls(result_dict)

                            if finish_reason != "tool_calls" or not tool_calls_list:
                                # Model is satisfied, exit loop
                                logger.info(f"Tool call loop complete after {iteration} iteration(s)")
                                break
                        else:
                            # Fallback: provider doesn't support chat_completions_create
                            logger.warning("Provider doesn't support chat_completions_create, tool execution may fail")
                            tool_output = ToolOutput(
                                status="error",
                                content="Provider doesn't support multi-turn tool execution",
                                content_type="text",
                            )
                            return [TextContent(type="text", text=tool_output.model_dump_json())]

                    if iteration >= max_iterations:
                        logger.warning(f"Tool call loop reached max iterations ({max_iterations})")

                    if not model_response or not model_response.content:
                        tool_output = ToolOutput(
                            status="error",
                            content="Model returned no response after tool execution",
                            content_type="text",
                        )
                        return [TextContent(type="text", text=tool_output.model_dump_json())]

                except Exception as e:
                    logger.error(f"Tool execution failed: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                    tool_output = ToolOutput(
                        status="error",
                        content=f"Tool execution error: {str(e)}",
                        content_type="text",
                    )
                    return [TextContent(type="text", text=tool_output.model_dump_json())]

            # Process the model's response
            # CRITICAL: Check finish_reason BEFORE checking content to detect truncation
            finish_reason = model_response.metadata.get("finish_reason", "unknown")

            # Check for incomplete or blocked responses FIRST
            if finish_reason in ["length", "content_filter"]:
                logger.warning(f"Response incomplete or blocked for {self.get_name()}. Finish reason: {finish_reason}")
                tool_output = ToolOutput(
                    status="error",
                    content=f"Response incomplete: {finish_reason}. "
                           f"{'Content was truncated due to length limit.' if finish_reason == 'length' else 'Content was filtered.'} "
                           f"Partial content: {getattr(model_response, 'content', '')[:200]}...",
                    content_type="text",
                    metadata={"finish_reason": finish_reason}
                )
            elif getattr(model_response, "content", None):
                raw_text = model_response.content

                # Create model info for conversation tracking
                # FIX (2025-10-24): Extract usage and metadata from model_response
                # so they're available to format_response() for metadata storage
                model_info = {
                    "provider": provider,
                    "model_name": self._current_model_name,
                    "model_response": model_response,
                    "tool_calls": tool_call_metadata if 'tool_call_metadata' in locals() else [],
                    "effective_prompt": prompt,
                }

                # Extract usage and metadata from model_response
                if hasattr(model_response, "usage"):
                    model_info["usage"] = model_response.usage
                elif isinstance(model_response, dict) and "usage" in model_response:
                    model_info["usage"] = model_response["usage"]

                if hasattr(model_response, "metadata"):
                    model_info["metadata"] = model_response.metadata
                elif isinstance(model_response, dict) and "metadata" in model_response:
                    model_info["metadata"] = model_response["metadata"]

                # Parse response using the same logic as old base.py
                tool_output = self._parse_response(raw_text, request, model_info)
                logger.info(f"{self.get_name()} tool completed successfully")

            else:
                # Handle cases where the model couldn't generate a response
                logger.warning(f"Response blocked or no content for {self.get_name()}. Finish reason: {finish_reason}")
                tool_output = ToolOutput(
                    status="error",
                    content=f"Response blocked or no content. Finish reason: {finish_reason}",
                    content_type="text",
                    metadata={"finish_reason": finish_reason}
                )

            # Return the tool output as TextContent
            # Attach tool_call_events metadata for UI dropdown if available
            if isinstance(tool_output.metadata, dict):
                try:
                    if 'tool_call_metadata' in locals() and tool_call_metadata:
                        tool_output.metadata.setdefault('tool_call_events', tool_call_metadata)
                    # Ensure dropdown visibility even when no provider-native tools were used
                    else:
                        import os as ___os, time as ___time
                        if ___os.getenv("EX_ALWAYS_TOOLCALL_METADATA", "false").strip().lower() == "true":
                            # Synthesize a minimal event so UIs show a dropdown
                            use_web_flag = False
                            try:
                                use_web_flag = self.get_request_use_websearch(request)
                            except Exception:
                                pass
                            synthetic = [{
                                "provider": getattr(provider.get_provider_type(), "value", str(provider)) if provider else "unknown",
                                "tool_name": self.get_name(),
                                "args": {
                                    "model": self._current_model_name,
                                    "use_websearch": bool(use_web_flag),
                                    "thinking_mode": thinking_mode,
                                },
                                "start_ts": ___time.time(),
                            }]
                            tool_output.metadata.setdefault('tool_call_events', synthetic)
                except Exception:
                    pass
            return [TextContent(type="text", text=tool_output.model_dump_json())]

        except Exception as e:
            # Special handling for MCP size check errors
            if str(e).startswith("MCP_SIZE_CHECK:"):
                # Extract the JSON content after the prefix
                json_content = str(e)[len("MCP_SIZE_CHECK:") :]
                return [TextContent(type="text", text=json_content)]

            logger.error(f"Error in {self.get_name()}: {str(e)}")
            error_output = ToolOutput(
                status="error",
                content=f"Error in {self.get_name()}: {str(e)}",
                content_type="text",
            )
            return [TextContent(type="text", text=error_output.model_dump_json())]

    def _parse_response(self, raw_text: str, request, model_info: Optional[dict] = None):
        """
        Parse the raw response and format it using the hook method.

        This simplified version focuses on the SimpleTool pattern: format the response
        using the format_response hook, then handle conversation continuation.
        """
        from tools.models import ToolOutput

        # CRITICAL FIX (2025-10-19): Create continuation_id BEFORE format_response()
        # so that format_response() can save the assistant response with the correct ID
        continuation_id = self.get_request_continuation_id(request)
        if not continuation_id:
            # First turn - create new continuation_id and attach to request
            # so format_response() can use it
            import uuid
            continuation_id = str(uuid.uuid4())
            request.continuation_id = continuation_id

        # Format the response using the hook method
        # ChatTool's format_response() will now have access to continuation_id
        formatted_response = self.format_response(raw_text, request, model_info)

        # Handle conversation continuation like old base.py
        continuation_id = self.get_request_continuation_id(request)
        if continuation_id:
            # Add turn to conversation memory
            # CRITICAL FIX (2025-10-24): Use global_storage to prevent 4x Supabase duplication
            from utils.conversation.global_storage import add_turn

            # Extract model metadata for conversation tracking
            model_provider = None
            model_name = None
            model_metadata = None

            if model_info:
                provider = model_info.get("provider")
                if provider:
                    # Handle both provider objects and string values
                    if isinstance(provider, str):
                        model_provider = provider
                    else:
                        try:
                            model_provider = provider.get_provider_type().value
                        except AttributeError:
                            # Fallback if provider doesn't have get_provider_type method
                            model_provider = str(provider)
                model_name = model_info.get("model_name")
                model_response = model_info.get("model_response")
                if model_response:
                    model_metadata = {"usage": model_response.usage, "metadata": model_response.metadata}

            # Only add the assistant's response to the conversation
            # The user's turn is handled elsewhere (when thread is created/continued)
            add_turn(
                continuation_id,  # thread_id as positional argument
                "assistant",  # role as positional argument
                raw_text,  # content as positional argument
                files=self.get_request_files(request),
                images=self.get_request_images(request),
                tool_name=self.get_name(),
                model_provider=model_provider,
                model_name=model_name,
                model_metadata=model_metadata,
            )

        # Create continuation offer like old base.py
        continuation_data = self._create_continuation_offer(request, model_info)
        if continuation_data:
            return self._create_continuation_offer_response(formatted_response, continuation_data, request, model_info)
        else:
            # Build metadata with model and provider info for success response
            metadata = {}
            if model_info:
                model_name = model_info.get("model_name")
                if model_name:
                    metadata["model_used"] = model_name
                provider = model_info.get("provider")
                if provider:
                    # Handle both provider objects and string values
                    if isinstance(provider, str):
                        metadata["provider_used"] = provider
                    else:
                        try:
                            metadata["provider_used"] = provider.get_provider_type().value
                        except AttributeError:
                            # Fallback if provider doesn't have get_provider_type method
                            metadata["provider_used"] = str(provider)

            return ToolOutput(
                status="success",
                content=formatted_response,
                content_type="text",
                metadata=metadata if metadata else None,
            )

    # Convenience methods for common tool patterns

    def build_standard_prompt(
        self, system_prompt: str, user_content: str, request, file_context_title: str = "CONTEXT FILES"
    ) -> str:
        """
        Build a standard prompt with system prompt, user content, and optional files.

        This is a convenience method that handles the common pattern of:
        1. Adding file content if present
        2. Checking token limits
        3. Adding web search instructions
        4. Combining everything into a well-formatted prompt

        Args:
            system_prompt: The system prompt for the tool
            user_content: The main user request/content
            request: The validated request object
            file_context_title: Title for the file context section

        Returns:
            Complete formatted prompt ready for the AI model
        """
        # Add context files if provided
        files = self.get_request_files(request)
        if files:
            file_content, processed_files = self._prepare_file_content_for_prompt(
                files,
                self.get_request_continuation_id(request),
                "Context files",
                model_context=getattr(self, "_model_context", None),
            )
            self._actually_processed_files = processed_files
            if file_content:
                # CRITICAL FIX (2025-10-17): Add explicit indicator that files are embedded (P0-5 fix)
                # The AI needs to be explicitly told that files are provided and available for analysis
                file_count = len(processed_files) if processed_files else "multiple"
                file_header = (
                    f"=== {file_context_title} (PROVIDED FOR ANALYSIS) ===\n"
                    f"NOTE: The following {file_count} file(s) have been embedded and are available for your analysis.\n"
                    f"You do NOT need to request these files - they are already provided below.\n\n"
                )
                user_content = f"{user_content}\n\n{file_header}{file_content}\n=== END CONTEXT ===="

        # Check token limits
        self._validate_token_limit(user_content, "Content")

        # Add web search instruction if enabled
        websearch_instruction = ""
        use_websearch = self.get_request_use_websearch(request)
        if use_websearch:
            websearch_instruction = self.get_websearch_instruction(use_websearch, self.get_websearch_guidance())

        # FIXED 2025-10-16: Do NOT include system prompt in user message!
        # System prompt goes in the system role, user content goes in user role
        # This was causing 81K token bloat by duplicating the system prompt
        full_prompt = f"""{websearch_instruction}

=== USER REQUEST ===
{user_content}
=== END REQUEST ===

Please provide a thoughtful, comprehensive response:"""

        return full_prompt

    def get_prompt_content_for_size_validation(self, user_content: str) -> str:
        """
        Override to use original user prompt for size validation when conversation history is embedded.

        When server.py embeds conversation history into the prompt field, it also stores
        the original user prompt in _original_user_prompt. We use that for size validation
        to avoid incorrectly triggering size limits due to conversation history.

        Args:
            user_content: The user content (may include conversation history)

        Returns:
            The original user prompt if available, otherwise the full user content
        """
        # Check if we have the current arguments from execute() method
        current_args = getattr(self, "_current_arguments", None)
        if current_args:
            # If server.py embedded conversation history, it stores original prompt separately
            # FIX: Handle both dict and ToolRequest object types
            if hasattr(current_args, 'get'):
                original_user_prompt = current_args.get("_original_user_prompt")
            else:
                original_user_prompt = getattr(current_args, "_original_user_prompt", None)
            if original_user_prompt is not None:
                # Use original user prompt for size validation (excludes conversation history)
                return original_user_prompt

        # Fallback to default behavior (validate full user content)
        return user_content

    def handle_prompt_file_with_fallback(self, request) -> str:
        """
        Handle prompt.txt files with fallback to request field.

        This is a convenience method for tools that accept prompts either
        as a field or as a prompt.txt file. It handles the extraction
        and validation automatically.

        Args:
            request: The validated request object

        Returns:
            The effective prompt content

        Raises:
            ValueError: If prompt is empty or too large for MCP transport
        """
        # Check for prompt.txt in files
        files = self.get_request_files(request)
        if files:
            prompt_content, updated_files = self.handle_prompt_file(files)

            # Update request files list if needed
            if updated_files is not None:
                self.set_request_files(request, updated_files)
        else:
            prompt_content = None

        # Use prompt.txt content if available, otherwise use the prompt field
        user_content = prompt_content if prompt_content else self.get_request_prompt(request)

        # CRITICAL FIX (Bug #7): Validate prompt is not empty
        # Empty prompts waste API calls and should be rejected early
        if not user_content or not user_content.strip():
            from tools.models import ToolOutput
            error_output = ToolOutput(
                status="invalid_request",
                error="Prompt cannot be empty. Please provide a non-empty prompt.",
                data={}
            )
            raise ValueError(f"MCP_VALIDATION_ERROR:{error_output.model_dump_json()}")

        # Check user input size at MCP transport boundary (excluding conversation history)
        validation_content = self.get_prompt_content_for_size_validation(user_content)
        size_check = self.check_prompt_size(validation_content)
        if size_check:
            from tools.models import ToolOutput

            raise ValueError(f"MCP_SIZE_CHECK:{ToolOutput(**size_check).model_dump_json()}")

        return user_content

    def supports_custom_request_model(self) -> bool:
        """
        Indicate whether this tool supports custom request models.

        Simple tools support custom request models by default. Tools that override
        get_request_model() to return something other than ToolRequest should
        return True here.

        Returns:
            True if the tool uses a custom request model
        """
        return self.get_request_model() != ToolRequest

    def _validate_file_paths(self, request) -> Optional[str]:
        """
        Validate that all file paths in the request are absolute paths.

        This is a security measure to prevent path traversal attacks and ensure
        proper access control. All file paths must be absolute (starting with '/').

        Args:
            request: The validated request object

        Returns:
            Optional[str]: Error message if validation fails, None if all paths are valid
        """
        import os
        from pathlib import Path
        from utils.file.operations import resolve_and_validate_path

        # Check if request has 'files' attribute (used by most tools)
        files = self.get_request_files(request)
        if files:
            # Compute repository root (two levels up from tools/simple/base.py -> repo root)
            repo_root = Path(__file__).resolve().parents[2]

            # Build allowed roots: repo root + TEST_FILES_DIR (supports multi-root via comma/semicolon/os.pathsep)
            allowed_roots = [repo_root]
            try:
                raw = os.getenv("TEST_FILES_DIR", "").strip()
                if raw:
                    seps = [",", ";", os.pathsep]
                    tmp = raw
                    for s in seps:
                        if s:
                            tmp = tmp.replace(s, ",")
                    tokens = [t.strip().strip('"').strip("'") for t in tmp.split(",") if t.strip()]
                    for tok in tokens:
                        try:
                            p = Path(tok).resolve()
                            if p.exists() and p.is_dir():
                                allowed_roots.append(p)
                        except Exception:
                            continue
            except Exception:
                pass

            # Import cross-platform path handler
            from utils.file.operations import get_path_handler
            path_handler = get_path_handler()

            # Track normalized paths to update the request
            normalized_files = []

            for file_path in files:
                # 1) Cross-platform path normalization (handles Windows paths on Linux)
                normalized_path, was_converted, error_message = path_handler.normalize_path(file_path)

                if error_message:
                    return error_message

                # Log conversion for debugging if enabled
                if was_converted and os.getenv('EX_DEBUG_PATH_CONVERSION', 'false').lower() == 'true':
                    logger.debug(f"Path converted: {file_path} -> {normalized_path}")

                # Use normalized path for subsequent operations
                file_path = normalized_path
                normalized_files.append(normalized_path)

                # 2) Secure resolution + containment check within allowed roots
                try:
                    resolved = resolve_and_validate_path(file_path)
                except (ValueError, PermissionError) as e:
                    return (
                        f"Error: Invalid or disallowed path: {file_path}\n"
                        f"Reason: {type(e).__name__}: {e}"
                    )

                # Ensure the path is within ANY allowed root
                permitted = False
                for root in allowed_roots:
                    try:
                        resolved.relative_to(root)
                        permitted = True
                        break
                    except Exception:
                        continue

                if not permitted:
                    allowed_str = "\n".join([f"- {str(r)}" for r in allowed_roots])
                    return (
                        f"Error: File path is outside permitted workspaces.\n"
                        f"Path: {file_path}\n"
                        f"Allowed roots:\n{allowed_str}"
                    )

            # Update the request object with normalized paths
            if normalized_files and hasattr(request, 'files'):
                request.files = normalized_files

        return None

    def prepare_chat_style_prompt(self, request, system_prompt: str = None) -> str:
        """
        Prepare a prompt using Chat tool-style patterns.

        This convenience method replicates the Chat tool's prompt preparation logic:
        1. Handle prompt.txt file if present
        2. Add file context with specific formatting
        3. Add web search guidance
        4. Format with system prompt

        Args:
            request: The validated request object
            system_prompt: System prompt to use (uses get_system_prompt() if None)

        Returns:
            Complete formatted prompt
        """
        # Use provided system prompt or get from tool
        if system_prompt is None:
            system_prompt = self.get_system_prompt()

        # Get user content (handles prompt.txt files)
        user_content = self.handle_prompt_file_with_fallback(request)

        # Build standard prompt with Chat-style web search guidance
        websearch_guidance = self.get_chat_style_websearch_guidance()

        # Override the websearch guidance temporarily
        original_guidance = self.get_websearch_guidance
        self.get_websearch_guidance = lambda: websearch_guidance

        try:
            full_prompt = self.build_standard_prompt(system_prompt, user_content, request, "CONTEXT FILES")
        finally:
            # Restore original guidance method
            self.get_websearch_guidance = original_guidance

        return full_prompt

    async def _route_and_execute(
        self,
        request,
        call_fn,
        is_retry: bool = False
    ):
        """
        Route request using hybrid router and execute with selected model.

        This method replaces the old call_with_fallback logic with the new
        hybrid router that combines MiniMax M2 intelligence with RouterService
        fallback for production reliability.

        Args:
            request: The validated request object
            call_fn: Function to call with selected model (e.g., _call_with_model)
            is_retry: True if this is a retry after explicit model failure

        Returns:
            Model response from the selected provider
        """
        from src.router.hybrid_router import get_hybrid_router

        # Get hybrid router instance
        hybrid_router = get_hybrid_router()

        # Build request context for routing
        # Include relevant details from the request for intelligent routing
        request_context = {
            "tool_name": self.get_name(),
            "requested_model": self._current_model_name,
            "images": self.get_request_images(request),
            "files": self.get_request_files(request),
            "use_websearch": self.get_request_use_websearch(request),
            "thinking_mode": self.get_request_thinking_mode(request),
            "temperature": self.get_request_temperature(request),
            "continuation_id": self.get_request_continuation_id(request),
            "is_retry": is_retry,
        }

        # Log routing attempt
        logger.info(
            f"[HYBRID_ROUTER] Routing request for tool '{self.get_name()}' "
            f"(auto mode, is_retry={is_retry})"
        )

        try:
            # Use hybrid router to get routing decision
            route_decision = await hybrid_router.route_request(
                tool_name=self.get_name(),
                request_context=request_context,
            )

            # Extract selected model from routing decision
            selected_model = route_decision.chosen
            routing_method = route_decision.meta.get("routing_method", "unknown") if route_decision.meta else "unknown"

            logger.info(
                f"[HYBRID_ROUTER] Selected model: {selected_model} via {routing_method} "
                f"(requested: {route_decision.requested})"
            )

            # Update instance variables to match selected model
            self._current_model_name = selected_model
            self._model_context.model_name = selected_model

            # Get provider for selected model
            registry_instance = get_registry_instance()
            provider = registry_instance.get_provider_for_model(selected_model)

            if not provider:
                raise RuntimeError(f"No provider available for selected model '{selected_model}'")

            # Update provider reference
            # Note: The call_fn closure will update the provider variable

            # Execute with selected model
            model_response = call_fn(selected_model)

            # Log successful execution
            logger.info(
                f"[HYBRID_ROUTER] Successfully executed with {selected_model} "
                f"via {routing_method}"
            )

            return model_response

        except Exception as e:
            logger.error(f"[HYBRID_ROUTER] Routing execution failed: {e}")

            # If hybrid routing fails, fall back to basic auto selection
            logger.warning("[HYBRID_ROUTER] Falling back to basic auto model selection")
            try:
                # Import and use router service for basic fallback
                from src.router.service import RouterService
                router_service = RouterService()
                basic_decision = router_service.choose_model("auto")
                fallback_model = basic_decision.chosen

                logger.info(f"[HYBRID_ROUTER] Fallback model: {fallback_model}")
                self._current_model_name = fallback_model
                self._model_context.model_name = fallback_model

                return call_fn(fallback_model)
            except Exception as fallback_error:
                logger.error(f"[HYBRID_ROUTER] Fallback also failed: {fallback_error}")
                raise e
